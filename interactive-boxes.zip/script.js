document.querySelectorAll(".box").forEach((box) => {
  box.addEventListener("click", function () {
    this.classList.toggle("open");
  });
});
